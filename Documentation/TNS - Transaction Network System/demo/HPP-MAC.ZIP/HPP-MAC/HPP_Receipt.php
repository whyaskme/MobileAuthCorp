<!-- 	This oage is a simple PHP to check the status of the transaction and retried the order 
		using an API operation. The merchant would normally check the successIndicator field with 
		the value from the Create Session request and if they match the transaction was successful.
		If the values do not match there was an error. The merchant can then optionally query the 
		API to download all the transaction details to store in their systems or to dispay a receipt.
-->


<?php 
session_start();

# Check if the successIndicator matches and grab the order.id from the session
if($_SESSION['successIndicator'] == $_GET['resultIndicator'] AND isset($_SESSION['orderid'])){
	# If the successIndicator matches, rewtrieve the order
	$serverURL = "https://secure.na.tnspayments.com/api/nvp/version/23";
	$requestString = "apiUsername=merchant.TESTASHMAC02&apiPassword=81874a0e40039cacd4036649214262d1&apiOperation=RETRIEVE_ORDER&merchant=TESTASHMAC02&order.id=". $_SESSION['orderid'];
	ob_start();
	$ch = curl_init();
	curl_setopt ($ch, CURLOPT_URL, $serverURL);
	curl_setopt ($ch, CURLOPT_POST, 1);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $requestString);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_exec ($ch);
	$response = ob_get_contents();
	ob_end_clean();
	# Output the details of the response to the screen. Normally a merchant would parse the data here and update thier systems as required.
if (strlen($response) != 0) {
	$pairArray = explode("&", $response);
	foreach ($pairArray as $pair) {
		$param = explode("=", $pair);
		$responseArray[urldecode($param[0])] = urldecode($param[1]);
	}
}
echo("<pre>");
print_r($responseArray);

# If the successIndicator doesnt exist, or the order.id is not present, display an error.
# Typically the merchant would look up the order.id from an internal system rather than storing in the session directly.
} else { 
	echo("FAILED MATCH");

}
?>