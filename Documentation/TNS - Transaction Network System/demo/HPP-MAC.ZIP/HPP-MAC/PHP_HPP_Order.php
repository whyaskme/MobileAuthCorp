<!--	This page will create a payment page session via the API, then render the HTML Form required
		to re-direct the customer to the TNSPay gateway. The HTML Form displayes the fields, but typically
		this type of data would be provided in hidden fields or on the session creation API operation.

-->

<?php

# Construct the Create Session API Operation	
	session_start();
	$orderid = rand();
	$serverURL = "https://secure.uat.tnspayments.com/api/nvp/version/23";

	$requestString  = "apiOperation=CREATE_PAYMENT_PAGE_SESSION&";
	$requestString .= "merchant=TESTASHMAC02&";
	$requestString .= "apiPassword=81874a0e40039cacd4036649214262d1&"; 
	$requestString .= "apiUsername=merchant.TESTASHMAC02&";
	$requestString .= "order.id=" . $orderid ."&";
	$requestString .= "order.amount=100.00&";
	$requestString .= "order.currency=USD&";
	$requestString .= "paymentPage.cancelUrl=http://localhost/HPP-MAC/HPP_Receipt.php&";
	$requestString .= "paymentPage.returnUrl=http://localhost/HPP-MAC/HPP_Receipt.php&";
	$requestString .= "order.custom.macOTPMerchantIdentifier=53ebb0977484691d4ce32a2f&";
	$requestString .= "order.custom.macOTPEndUserPhoneNumber=13604814563&";
	$requestString .= "order.custom.macOTPEndUserEmail=aforsyth@tnsi.com";
	
	
# Send the API operation to create a payment page session	
	ob_start();
	$ch = curl_init();
	curl_setopt ($ch, CURLOPT_URL, $serverURL);
	curl_setopt ($ch, CURLOPT_POST, 1);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, $requestString);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_exec ($ch);
	$response = ob_get_contents();
	ob_end_clean();
	
	# Get the response ot the API operation and parse the data (mostly for this demo display purposes)
	if (strlen($response) != 0) {
		$pairArray = explode("&", $response);
		foreach ($pairArray as $pair) {
			$param = explode("=", $pair);
			$responseArray[urldecode($param[0])] = urldecode($param[1]);
		}
	}

# Store the successIndicator in the session since this demo does not persist any data in a DB.
# A merchant should store this in a DB and not in a session and compare it with the response coming back
# If the successIndicator matches the value coming back from TNSPay, the transaction was successful
$_SESSION['successIndicator'] = $responseArray['successIndicator'];

# Store the order.id value in the session since persistance storage is not available in this demo
# Normally this should be stored on the server side and matched to the user session
$_SESSION['orderid'] = $orderid





?>

<!-- Start the basic brainding/display of this page -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head><title>HPP Client Example</title>
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="expires" content="0" />
    <style type='text/css'>
        <!--
        H1       { font-family:Arial,sans-serif; font-size:20pt; color:#08185A; font-weight:600; margin-bottom:0.1em}
        H2       { font-family:Arial,sans-serif; font-size:14pt; color:#08185A; font-weight:100; margin-top:0.1em}
        H2.co    { font-family:Arial,sans-serif; font-size:24pt; color:#08185A; margin-top:0.1em; margin-bottom:0.1em; font-weight:100}
        H3.co    { font-family:Arial,sans-serif; font-size:16pt; color:#FFFFFF; margin-top:0.1em; margin-bottom:0.1em; font-weight:100}
        BODY     { font-family:Verdana,Arial,sans-serif; font-size:10pt; color:#08185A background-color:#FFFFFF }
        TR       { height:25px; }
        TR.shade { height:25px; background-color:#CED7EF }
        TR.title { height:25px; background-color:#0074C4 }
        TD       { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#08185A }
        P        { font-family:Verdana,Arial,sans-serif; font-size:10pt; color:#FFFFFF }
        P.blue   { font-family:Verdana,Arial,sans-serif; font-size:7pt;  color:#08185A }
        P.red    { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#FF0066 }
        P.green  { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#00AA00 }
        DIV.bl   { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#0074C4 }
        LI       { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#FF0066 }
        INPUT    { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#08185A; background-color:#CED7EF; font-weight:bold }
        SELECT   { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#08185A; background-color:#CED7EF; font-weight:bold }
        TEXTAREA { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#08185A; background-color:#CED7EF; font-weight:normal; scrollbar-arrow-color:#08185A; scrollbar-base-color:#CED7EF }
        A:link   { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#08185A }
        A:visited{ font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#08185A }
        A:hover  { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#FF0000 }
        A:active { font-family:Verdana,Arial,sans-serif; font-size:8pt;  color:#FF0000 }
        -->
    </style>
</head>
<body>
	
	<table width='100%' border='2' cellpadding='2' bgcolor='#0074C4'>
    <tr>
        <td bgcolor='#CED7EF' width='90%'><h2 class='co'>&nbsp;HPP Return to Merchant Example</h2></td>
    </tr>
</table>

<br/><br/>

<table width="75%" align="center" border="0" cellpadding='0' cellspacing='0'>

<!-- display the session creation details to screen for demo display purposes only -->
	<tr class="title">
	    <td colspan="2" height="25"><p><strong>&nbsp;HPP Session Creation</strong></p></td>
	</tr>
	<tr>
		<td width="15%"><strong>Request URL</strong></td>
		<td><?php echo $serverURL ?></td>
	</tr>
	
	<tr>
		<td><strong>Request Data</strong></td>
		<td><?php echo str_replace("&", " & ", $requestString) ?></td>
	</tr>
	<tr><td colspan="2">&nbsp;<hr width="75%">&nbsp;</td></tr>
	
	<tr>
		<td><strong>Response Data</strong></td>
		<td><?php print_r($pairArray)?></td>
	</tr>
	<tr><td colspan="2">&nbsp;</td></tr>
	<tr><td colspan="2">&nbsp;</td></tr>
	
<!-- Create the Payment Form that triggers the re-direct to TNSPay -->
<form action="https://secure.uat.tnspayments.com/api/page/version/23/pay" method="post" accept-charset="UTF-8">
	<tr class="title">
	    <td colspan="2" height="25"><p><strong>&nbsp;HPP HTML Form</strong></p></td>
	</tr>
	<!-- Pass the session in the request -->
	<tr>
		<td><strong>session</strong></td>
		<td><input type="text" name = "session.id" value = "<?php echo($responseArray['session.id']); ?>" readonly size = "100" /></td>
	</tr>
	<!-- Pass additional/optional fields in the request -->
	<tr>
		<td><strong>order.description</strong></td>
		<td><input type="text" name = "order.description" value = "Test Goods" readonly size = "100" /></td>
	</tr>
	<tr>
		<td><strong>paymentPage.merchant.name</strong></td>
		<td><input type="text" name = "paymentPage.merchant.name" value = "Test Goods" readonly size = "100" /></td>
	</tr>
	<tr><td colspan="2"><center><input type="submit"  value="Checkout"></center></td></tr>
</form>	
	

</table>






</body>

<head>
    <meta http-equiv="cache-control" content="no-cache" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="expires" content="0" />
</head>
</html>
